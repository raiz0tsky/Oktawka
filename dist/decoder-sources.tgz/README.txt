Oktawka uses the unmodified @wasm-audio-decoders/flac 0.2.11 browser bundle.
Included npm source packages provide the FLAC wrapper and LGPL codec-parser source.
The decoder source/build recipe and common/worker code are available at:
https://github.com/eshaz/wasm-audio-decoders/tree/main/src/flac
https://github.com/eshaz/wasm-audio-decoders/tree/main/src/common
https://github.com/eshaz/codec-parser/tree/v2.5.0
libFLAC source is available at https://github.com/xiph/flac
Replace /flac-decoder.min.js with a compatible rebuilt library to relink it.
Oktawka does not prevent modifying/replacing that separately loaded library.
See supplied notices for the MIT, LGPL and Xiph BSD licenses.
